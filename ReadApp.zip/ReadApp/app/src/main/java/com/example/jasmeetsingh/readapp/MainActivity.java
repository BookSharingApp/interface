package com.example.jasmeetsingh.readapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import static android.provider.AlarmClock.EXTRA_MESSAGE;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    /** Called when the user taps the Send button */
    public void login (View view) {
        // Do something in response to button
        Intent intent = new Intent(this, MainPage.class);
        startActivity(intent);
    }
    public void forgotpassword(View view2) {
        // Do something in response to button
        Intent forgot_pass = new Intent(this, Forgotpassword.class);
        startActivity(forgot_pass);
    }
    public void newaccount(View view3) {
        // Do something in response to button
        Intent new_account = new Intent(this, newaccount.class);
        startActivity(new_account);
    }
}
