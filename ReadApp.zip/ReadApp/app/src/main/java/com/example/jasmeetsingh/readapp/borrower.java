package com.example.jasmeetsingh.readapp;

import java.sql.Blob;
import java.util.Date;

/**
 * Created by Jasmeet Singh on 16-03-2018.
 */

public class borrower {
    // fields
    private String borrower_id;
    private String lenders_id;
    private int book_id;
    private java.sql.Date date_of_return;
    private java.sql.Date date_of_borrow;
    // constructors
    public borrower() {}
    public borrower(String borrower_id, String lenders_id, int book_id, java.sql.Date date_of_return, java.sql.Date date_of_borrow) {
        this.borrower_id = borrower_id;
        this.lenders_id = lenders_id;
        this.book_id = book_id;
        this.date_of_return = date_of_return;
        this.date_of_borrow = date_of_borrow;
    }
    // properties
    public void set_borrower_id(String borrower_id) {
        this.borrower_id = borrower_id;
    }
    public String get_borrower_id() {
        return this.borrower_id;
    }
    public void set_lenders_id(String lenders_id) {
        this.lenders_id = lenders_id;
    }
    public String get_lenders_id() {
        return this.lenders_id;
    }
    public void set_book_id(int book_id) {
        this.book_id = book_id;
    }
    public int get_book_id() {
        return this.book_id;
    }
    public void set_doreturn(java.sql.Date date_of_return) {
        this.date_of_return = date_of_return;
    }
    public java.sql.Date get_doreturn() {
        return this.date_of_return;
    }
    public void set_doborrow(java.sql.Date date_of_borrow) {
        this.date_of_borrow = date_of_borrow;
    }
    public java.sql.Date get_doborrow() {
        return this.date_of_borrow;
    }
}
