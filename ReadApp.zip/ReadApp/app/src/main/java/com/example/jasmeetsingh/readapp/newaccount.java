package com.example.jasmeetsingh.readapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class newaccount extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newaccount);
    }
    //ADD ROW
    public void addPD(View v) {
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
/*
        String email_idPD = email_id.getText().toString();
        String passwordPD = password.getText().toString();
        String namePD = name.getText().toString();
        double ph_noPD = double.parsedouble(ph_no.getText().toString());
        String addressPD = address.getText().toString();
        PersonalDetails pd = new PersonalDetails(email_idPD, passwordPD, namePD, ph_noPD, addPD);
        dbHandler.add_PDetails(pd);
        email_id.setText("");
        password.setText("");
        name.setText("");
        ph_no.setText("");
        address.setText("");*/
    }
}
